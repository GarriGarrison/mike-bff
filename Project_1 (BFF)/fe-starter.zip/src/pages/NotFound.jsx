export const NotFound = () => {
  return <div>This page doesn&apos;t exist</div>;
};
